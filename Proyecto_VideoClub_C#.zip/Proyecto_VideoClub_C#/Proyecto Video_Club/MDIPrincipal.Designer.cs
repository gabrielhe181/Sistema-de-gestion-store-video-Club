﻿namespace Proyecto_Video_Club
{
    partial class MDIPrincipal
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MDIPrincipal));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.mnuArchivo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuArchivoCopia = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuArchivoRestaurar = new System.Windows.Forms.ToolStripMenuItem();
            this.imprimirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuArchivoSalir = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuIntroducir = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuIntroducirSocio = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuIntroducirPelicula = new System.Windows.Forms.ToolStripMenuItem();
            this.modificarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.socioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.películaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.socioToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.películaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPrestamos = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPrestamosPrestarPelicula = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPrestamosDevolverPelicula = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInformes = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInformesBusquedas = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInformesBuscarBuscarPelicula = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInformesBuscarBuscarSocio = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAyuda = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAyudaContenido = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuAyudaAcercade = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.mnuCopiaSeguridad = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuRestaurar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuImprimir = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuBuscar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.alquileresFueraDeTiempoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.toolStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuArchivo,
            this.mnuIntroducir,
            this.modificarToolStripMenuItem,
            this.eliminarToolStripMenuItem,
            this.mnuPrestamos,
            this.mnuInformes,
            this.mnuAyuda});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.MdiWindowListItem = this.mnuInformes;
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(632, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // mnuArchivo
            // 
            this.mnuArchivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuArchivoCopia,
            this.mnuArchivoRestaurar,
            this.imprimirToolStripMenuItem,
            this.toolStripSeparator4,
            this.mnuArchivoSalir});
            this.mnuArchivo.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.mnuArchivo.Name = "mnuArchivo";
            this.mnuArchivo.Size = new System.Drawing.Size(60, 20);
            this.mnuArchivo.Text = "&Archivo";
            // 
            // mnuArchivoCopia
            // 
            this.mnuArchivoCopia.Image = ((System.Drawing.Image)(resources.GetObject("mnuArchivoCopia.Image")));
            this.mnuArchivoCopia.ImageTransparentColor = System.Drawing.Color.Black;
            this.mnuArchivoCopia.Name = "mnuArchivoCopia";
            this.mnuArchivoCopia.Size = new System.Drawing.Size(185, 22);
            this.mnuArchivoCopia.Text = "Copia de seguridad...";
            this.mnuArchivoCopia.Click += new System.EventHandler(this.mnuArchivoCopia_Click);
            // 
            // mnuArchivoRestaurar
            // 
            this.mnuArchivoRestaurar.Image = ((System.Drawing.Image)(resources.GetObject("mnuArchivoRestaurar.Image")));
            this.mnuArchivoRestaurar.ImageTransparentColor = System.Drawing.Color.Black;
            this.mnuArchivoRestaurar.Name = "mnuArchivoRestaurar";
            this.mnuArchivoRestaurar.Size = new System.Drawing.Size(185, 22);
            this.mnuArchivoRestaurar.Text = "Restaurar...";
            this.mnuArchivoRestaurar.Click += new System.EventHandler(this.ShowNewForm);
            // 
            // imprimirToolStripMenuItem
            // 
            this.imprimirToolStripMenuItem.Name = "imprimirToolStripMenuItem";
            this.imprimirToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.imprimirToolStripMenuItem.Text = "Imprimir";
            this.imprimirToolStripMenuItem.Click += new System.EventHandler(this.imprimirToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(182, 6);
            // 
            // mnuArchivoSalir
            // 
            this.mnuArchivoSalir.Name = "mnuArchivoSalir";
            this.mnuArchivoSalir.Size = new System.Drawing.Size(185, 22);
            this.mnuArchivoSalir.Text = "&Salir";
            this.mnuArchivoSalir.Click += new System.EventHandler(this.ExitToolsStripMenuItem_Click);
            // 
            // mnuIntroducir
            // 
            this.mnuIntroducir.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuIntroducirSocio,
            this.mnuIntroducirPelicula});
            this.mnuIntroducir.Name = "mnuIntroducir";
            this.mnuIntroducir.Size = new System.Drawing.Size(71, 20);
            this.mnuIntroducir.Text = "&Introducir";
            // 
            // mnuIntroducirSocio
            // 
            this.mnuIntroducirSocio.Name = "mnuIntroducirSocio";
            this.mnuIntroducirSocio.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.mnuIntroducirSocio.Size = new System.Drawing.Size(156, 22);
            this.mnuIntroducirSocio.Text = "Socio";
            this.mnuIntroducirSocio.Click += new System.EventHandler(this.mnuIntroducirSocio_Click);
            // 
            // mnuIntroducirPelicula
            // 
            this.mnuIntroducirPelicula.Name = "mnuIntroducirPelicula";
            this.mnuIntroducirPelicula.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.mnuIntroducirPelicula.Size = new System.Drawing.Size(156, 22);
            this.mnuIntroducirPelicula.Text = "Película";
            this.mnuIntroducirPelicula.Click += new System.EventHandler(this.mnuIntroducirPelicula_Click);
            // 
            // modificarToolStripMenuItem
            // 
            this.modificarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.socioToolStripMenuItem,
            this.películaToolStripMenuItem});
            this.modificarToolStripMenuItem.Name = "modificarToolStripMenuItem";
            this.modificarToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.modificarToolStripMenuItem.Text = "&Modificar";
            // 
            // socioToolStripMenuItem
            // 
            this.socioToolStripMenuItem.Name = "socioToolStripMenuItem";
            this.socioToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.socioToolStripMenuItem.Text = "Socio";
            this.socioToolStripMenuItem.Click += new System.EventHandler(this.socioToolStripMenuItem_Click);
            // 
            // películaToolStripMenuItem
            // 
            this.películaToolStripMenuItem.Name = "películaToolStripMenuItem";
            this.películaToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.películaToolStripMenuItem.Text = "Película";
            this.películaToolStripMenuItem.Click += new System.EventHandler(this.películaToolStripMenuItem_Click);
            // 
            // eliminarToolStripMenuItem
            // 
            this.eliminarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.socioToolStripMenuItem1,
            this.películaToolStripMenuItem1});
            this.eliminarToolStripMenuItem.Name = "eliminarToolStripMenuItem";
            this.eliminarToolStripMenuItem.Size = new System.Drawing.Size(62, 20);
            this.eliminarToolStripMenuItem.Text = "&Eliminar";
            // 
            // socioToolStripMenuItem1
            // 
            this.socioToolStripMenuItem1.Name = "socioToolStripMenuItem1";
            this.socioToolStripMenuItem1.Size = new System.Drawing.Size(115, 22);
            this.socioToolStripMenuItem1.Text = "Socio";
            this.socioToolStripMenuItem1.Click += new System.EventHandler(this.socioToolStripMenuItem1_Click);
            // 
            // películaToolStripMenuItem1
            // 
            this.películaToolStripMenuItem1.Name = "películaToolStripMenuItem1";
            this.películaToolStripMenuItem1.Size = new System.Drawing.Size(115, 22);
            this.películaToolStripMenuItem1.Text = "Película";
            this.películaToolStripMenuItem1.Click += new System.EventHandler(this.películaToolStripMenuItem1_Click);
            // 
            // mnuPrestamos
            // 
            this.mnuPrestamos.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuPrestamosPrestarPelicula,
            this.mnuPrestamosDevolverPelicula});
            this.mnuPrestamos.Name = "mnuPrestamos";
            this.mnuPrestamos.Size = new System.Drawing.Size(71, 20);
            this.mnuPrestamos.Text = "&Alquileres";
            // 
            // mnuPrestamosPrestarPelicula
            // 
            this.mnuPrestamosPrestarPelicula.Name = "mnuPrestamosPrestarPelicula";
            this.mnuPrestamosPrestarPelicula.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.mnuPrestamosPrestarPelicula.Size = new System.Drawing.Size(209, 22);
            this.mnuPrestamosPrestarPelicula.Text = "Alquilar película...";
            this.mnuPrestamosPrestarPelicula.Click += new System.EventHandler(this.mnuPrestamosPrestarPelicula_Click);
            // 
            // mnuPrestamosDevolverPelicula
            // 
            this.mnuPrestamosDevolverPelicula.Name = "mnuPrestamosDevolverPelicula";
            this.mnuPrestamosDevolverPelicula.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
            this.mnuPrestamosDevolverPelicula.Size = new System.Drawing.Size(209, 22);
            this.mnuPrestamosDevolverPelicula.Text = "Devolver película";
            this.mnuPrestamosDevolverPelicula.Click += new System.EventHandler(this.mnuPrestamosDevolverPelicula_Click);
            // 
            // mnuInformes
            // 
            this.mnuInformes.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alquileresFueraDeTiempoToolStripMenuItem,
            this.mnuInformesBusquedas});
            this.mnuInformes.Name = "mnuInformes";
            this.mnuInformes.Size = new System.Drawing.Size(66, 20);
            this.mnuInformes.Text = "&Informes";
            // 
            // mnuInformesBusquedas
            // 
            this.mnuInformesBusquedas.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuInformesBuscarBuscarPelicula,
            this.mnuInformesBuscarBuscarSocio});
            this.mnuInformesBusquedas.Name = "mnuInformesBusquedas";
            this.mnuInformesBusquedas.Size = new System.Drawing.Size(216, 22);
            this.mnuInformesBusquedas.Text = "Búsquedas";
            this.mnuInformesBusquedas.Click += new System.EventHandler(this.TileHorizontalToolStripMenuItem_Click);
            // 
            // mnuInformesBuscarBuscarPelicula
            // 
            this.mnuInformesBuscarBuscarPelicula.Name = "mnuInformesBuscarBuscarPelicula";
            this.mnuInformesBuscarBuscarPelicula.Size = new System.Drawing.Size(162, 22);
            this.mnuInformesBuscarBuscarPelicula.Text = "Buscar película...";
            this.mnuInformesBuscarBuscarPelicula.Click += new System.EventHandler(this.mnuInformesBuscarBuscarPelicula_Click);
            // 
            // mnuInformesBuscarBuscarSocio
            // 
            this.mnuInformesBuscarBuscarSocio.Name = "mnuInformesBuscarBuscarSocio";
            this.mnuInformesBuscarBuscarSocio.Size = new System.Drawing.Size(162, 22);
            this.mnuInformesBuscarBuscarSocio.Text = "Buscar socio...";
            this.mnuInformesBuscarBuscarSocio.Click += new System.EventHandler(this.mnuInformesBuscarBuscarSocio_Click);
            // 
            // mnuAyuda
            // 
            this.mnuAyuda.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuAyudaContenido,
            this.toolStripSeparator8,
            this.mnuAyudaAcercade});
            this.mnuAyuda.Name = "mnuAyuda";
            this.mnuAyuda.Size = new System.Drawing.Size(53, 20);
            this.mnuAyuda.Text = "Ay&uda";
            // 
            // mnuAyudaContenido
            // 
            this.mnuAyudaContenido.Name = "mnuAyudaContenido";
            this.mnuAyudaContenido.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F1)));
            this.mnuAyudaContenido.Size = new System.Drawing.Size(176, 22);
            this.mnuAyudaContenido.Text = "Contenido";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(173, 6);
            // 
            // mnuAyudaAcercade
            // 
            this.mnuAyudaAcercade.Name = "mnuAyudaAcercade";
            this.mnuAyudaAcercade.Size = new System.Drawing.Size(176, 22);
            this.mnuAyudaAcercade.Text = "Acerca de...";
            this.mnuAyudaAcercade.Click += new System.EventHandler(this.mnuAyudaAcercade_Click);
            // 
            // toolStrip
            // 
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuCopiaSeguridad,
            this.toolStripSeparator5,
            this.mnuRestaurar,
            this.toolStripSeparator1,
            this.mnuImprimir,
            this.toolStripSeparator2,
            this.mnuBuscar,
            this.toolStripSeparator6});
            this.toolStrip.Location = new System.Drawing.Point(0, 24);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(632, 25);
            this.toolStrip.TabIndex = 1;
            this.toolStrip.Text = "ToolStrip";
            // 
            // mnuCopiaSeguridad
            // 
            this.mnuCopiaSeguridad.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.mnuCopiaSeguridad.Image = ((System.Drawing.Image)(resources.GetObject("mnuCopiaSeguridad.Image")));
            this.mnuCopiaSeguridad.ImageTransparentColor = System.Drawing.Color.Black;
            this.mnuCopiaSeguridad.Name = "mnuCopiaSeguridad";
            this.mnuCopiaSeguridad.Size = new System.Drawing.Size(23, 22);
            this.mnuCopiaSeguridad.Text = "Guardar";
            this.mnuCopiaSeguridad.Click += new System.EventHandler(this.mnuCopiaSeguridad_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // mnuRestaurar
            // 
            this.mnuRestaurar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.mnuRestaurar.Image = ((System.Drawing.Image)(resources.GetObject("mnuRestaurar.Image")));
            this.mnuRestaurar.ImageTransparentColor = System.Drawing.Color.Black;
            this.mnuRestaurar.Name = "mnuRestaurar";
            this.mnuRestaurar.Size = new System.Drawing.Size(23, 22);
            this.mnuRestaurar.Text = "Abrir";
            this.mnuRestaurar.Click += new System.EventHandler(this.OpenFile);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // mnuImprimir
            // 
            this.mnuImprimir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.mnuImprimir.Image = ((System.Drawing.Image)(resources.GetObject("mnuImprimir.Image")));
            this.mnuImprimir.ImageTransparentColor = System.Drawing.Color.Black;
            this.mnuImprimir.Name = "mnuImprimir";
            this.mnuImprimir.Size = new System.Drawing.Size(23, 22);
            this.mnuImprimir.Text = "Imprimir";
            this.mnuImprimir.Click += new System.EventHandler(this.mnuImprimir_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // mnuBuscar
            // 
            this.mnuBuscar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.mnuBuscar.Image = ((System.Drawing.Image)(resources.GetObject("mnuBuscar.Image")));
            this.mnuBuscar.ImageTransparentColor = System.Drawing.Color.Black;
            this.mnuBuscar.Name = "mnuBuscar";
            this.mnuBuscar.Size = new System.Drawing.Size(23, 22);
            this.mnuBuscar.Text = "Vista previa de impresión";
            this.mnuBuscar.Click += new System.EventHandler(this.mnuBuscar_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 431);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(632, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(42, 17);
            this.toolStripStatusLabel.Text = "Estado";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // alquileresFueraDeTiempoToolStripMenuItem
            // 
            this.alquileresFueraDeTiempoToolStripMenuItem.Name = "alquileresFueraDeTiempoToolStripMenuItem";
            this.alquileresFueraDeTiempoToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.alquileresFueraDeTiempoToolStripMenuItem.Text = "Alquileres fuera de tiempo";
            this.alquileresFueraDeTiempoToolStripMenuItem.Click += new System.EventHandler(this.alquileresFueraDeTiempoToolStripMenuItem_Click);
            // 
            // MDIPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 453);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.toolStrip);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MDIPrincipal";
            this.Text = "Videoclub Presin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem mnuAyudaAcercade;
        private System.Windows.Forms.ToolStripMenuItem mnuInformesBusquedas;
        private System.Windows.Forms.ToolStripMenuItem mnuArchivo;
        private System.Windows.Forms.ToolStripMenuItem mnuArchivoCopia;
        private System.Windows.Forms.ToolStripMenuItem mnuArchivoSalir;
        private System.Windows.Forms.ToolStripMenuItem mnuIntroducir;
        private System.Windows.Forms.ToolStripMenuItem mnuPrestamos;
        private System.Windows.Forms.ToolStripMenuItem mnuPrestamosPrestarPelicula;
        private System.Windows.Forms.ToolStripMenuItem mnuInformes;
        private System.Windows.Forms.ToolStripMenuItem mnuAyuda;
        private System.Windows.Forms.ToolStripMenuItem mnuAyudaContenido;
        private System.Windows.Forms.ToolStripButton mnuRestaurar;
        private System.Windows.Forms.ToolStripButton mnuCopiaSeguridad;
        private System.Windows.Forms.ToolStripButton mnuImprimir;
        private System.Windows.Forms.ToolStripButton mnuBuscar;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem mnuArchivoRestaurar;
        private System.Windows.Forms.ToolStripMenuItem mnuIntroducirSocio;
        private System.Windows.Forms.ToolStripMenuItem mnuIntroducirPelicula;
        private System.Windows.Forms.ToolStripMenuItem mnuPrestamosDevolverPelicula;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem mnuInformesBuscarBuscarPelicula;
        private System.Windows.Forms.ToolStripMenuItem mnuInformesBuscarBuscarSocio;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.ToolStripMenuItem imprimirToolStripMenuItem;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.ToolStripMenuItem modificarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eliminarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem socioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem películaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem socioToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem películaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem alquileresFueraDeTiempoToolStripMenuItem;
    }
}



