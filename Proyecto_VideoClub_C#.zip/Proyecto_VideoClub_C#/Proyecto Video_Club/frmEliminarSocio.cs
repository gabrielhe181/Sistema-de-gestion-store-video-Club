﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace Proyecto_Video_Club
{
    public partial class frmEliminarSocio : Form
    {
        OleDbConnection cadena = new OleDbConnection();
        OleDbCommand comando = new OleDbCommand();
        string path_Bd;
        string cs;
        OleDbConnection cn = new OleDbConnection();
        public frmEliminarSocio()
        {
            InitializeComponent();
        }

        private void frmEliminarSocio_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet.Socios' Puede moverla o quitarla según sea necesario.
            this.sociosTableAdapter.Fill(this._videoclub_brandomDataSet.Socios);
            if (sociosBindingSource.Count == 0) { MessageBox.Show("No existen registros para eliminar", "Aviso"); Close(); }
            DataGridViewButtonColumn modificar = new DataGridViewButtonColumn();
            dataGridView2.Columns.Add(modificar);
            modificar.Text = "Eliminar Película";
            modificar.Name = "btnBoton";
            modificar.UseColumnTextForButtonValue = true;
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DialogResult deb = new DialogResult();
            int index = e.ColumnIndex;
            int indexRow;
            indexRow = e.RowIndex;
            if (index == 6)
            {
                deb = MessageBox.Show("¿Seguro que desea devolver está película?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (deb == DialogResult.Yes)
                {
                    sociosBindingSource.RemoveCurrent();
                    MessageBox.Show("Registro eliminado correctamente");
                }
                else
                {

                }
            }
        }

        
    }

}
