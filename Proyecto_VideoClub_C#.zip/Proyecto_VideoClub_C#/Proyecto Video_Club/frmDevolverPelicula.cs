﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Proyecto_Video_Club
{
    public partial class frmDevolverPelicula : Form
    {
        public frmDevolverPelicula()
        {
            InitializeComponent();
        }

        private void frmDevolverPelicula_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet.Prestamo' Puede moverla o quitarla según sea necesario.
            this.prestamoTableAdapter.Fill(this._videoclub_brandomDataSet.Prestamo);
            prestamoBindingSource.Filter = "Devuelto='True'";
            DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
            dataGridView2.Columns.Add(btn);
            btn.Text = "Devolver Película";
            btn.Name = "btnBoton";
            btn.UseColumnTextForButtonValue = true;
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DialogResult deb = new DialogResult();
            int index = e.ColumnIndex;
            int indexRow; 
            indexRow = e.RowIndex;
            if (index == 9)
            { deb = MessageBox.Show("¿Seguro que desea devolver está película?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (deb == DialogResult.Yes)
                {   
                    DateTime fecha1 = new DateTime();
                    DateTime fecha2 = new DateTime();
                    DateTime fechaOriginal = new DateTime();
                    double total;
                    total = Convert.ToDouble(dataGridView2[6, indexRow].Value.ToString());
                    
                    fecha1 = System.DateTime.Parse(dataGridView2[4, indexRow].Value.ToString());
                    fecha1.AddDays(1);
                    fecha2 = System.DateTime.Parse(dataGridView2[5, indexRow].Value.ToString());
                    if (fecha2 == fecha1.AddDays(1))
                    {

                        dataGridView2[7, indexRow].Value = 0;
                        dataGridView2[7, indexRow].Value = total;
                        dataGridView2[8, indexRow].Value = false;
                        MessageBox.Show("El costo a pagar es de: $" + total + "");
                        this.prestamoBindingSource.EndEdit();
                        prestamoTableAdapter.Update(_videoclub_brandomDataSet.Prestamo);
                        _videoclub_brandomDataSet.AcceptChanges();
                        dataGridView2.DataSource = prestamoBindingSource;
                    }
                    else if (fechaOriginal == fecha2)
                    {
                        dataGridView2[7, indexRow].Value = 0;
                        dataGridView2[7, indexRow].Value = total;
                        dataGridView2[8, indexRow].Value = false;
                        MessageBox.Show("El costo a pagar es de: $" + total + "");
                        this.prestamoBindingSource.EndEdit();
                        prestamoTableAdapter.Update(_videoclub_brandomDataSet.Prestamo);
                        _videoclub_brandomDataSet.AcceptChanges();
                        dataGridView2.DataSource = prestamoBindingSource;
                    }
                    else
                    {
                        double totales = total + total;
                        dataGridView2[7, indexRow].Value = 0;
                        dataGridView2[7, indexRow].Value = totales;
                        dataGridView2[8, indexRow].Value = false;
                        MessageBox.Show("El costo a pagar es de: $" + totales + "");
                        this.prestamoBindingSource.EndEdit();
                        prestamoTableAdapter.Update(_videoclub_brandomDataSet.Prestamo);
                        _videoclub_brandomDataSet.AcceptChanges();
                        dataGridView2.DataSource = prestamoBindingSource;
                    }
                    
                    
                }                
                else
                { 
                
                }
            }
        }

        

        

        

       
    }
}
