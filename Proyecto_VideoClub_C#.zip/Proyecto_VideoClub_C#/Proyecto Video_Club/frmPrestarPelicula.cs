﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Proyecto_Video_Club
{
    public partial class frmPrestarPelicula : Form
    {
        decimal alquiler;
        string nif1;
        string nombre1;
        string apellido1;
        int registroPeli;
        string tituloPeli = "";
        public frmPrestarPelicula()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DateTime fecha = System.DateTime.Now;
            fecha = fecha.AddDays(1);
            alquiler = Convert.ToDecimal(txtPrecioAlquiler.Text);
            if (nombre1 == "" || apellido1 == "" || nif1 == "" || tituloPeli == "" || alquiler == 0)
            {
                MessageBox.Show("Faltan datos para generar un alquiler");
            }
            else

            {
                prestamoBindingSource.Filter = "[Registro Película]='" + registroPeli + "' AND Devuelto='True'";
                if (prestamoBindingSource.Count > 0)
                {
                    MessageBox.Show("La película ya está alquilada", "Aviso");
                    limpiar();
                    prestamoBindingSource.CancelEdit();
                }
                else
                {
                    prestamoTableAdapter.Insert(registroPeli, nif1, System.DateTime.Today, fecha, true, tituloPeli, nombre1, apellido1, alquiler, 0);
                    MessageBox.Show("Alquiler realizado con éxito");
                    prestamoBindingSource.Filter="";
                    limpiar();
                }
            }
        }
        private void limpiar()
        {
            nombre1 = "";
            apellido1 ="";
            nif1 = "";
            tituloPeli = "";
            lblOkPel.Text = "0";
            lblOkSoc.Text = "0";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            peliculasBindingSource.Filter = "Titulo Like '" + txtPelicula.Text + "%'";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sociosBindingSource.Filter = "Nombre Like '" + txtSocio.Text + "%' Or Apellidos Like '" + txtSocio.Text + "%'";
        }

        private void txtSocio_TextChanged(object sender, EventArgs e)
        {
            if (txtSocio.Text == "")
            {
                sociosBindingSource.Filter = "";
            }
        }

        private void txtPelicula_TextChanged(object sender, EventArgs e)
        {
            if (txtPelicula.Text == "")
            { peliculasBindingSource.Filter = ""; }
        }

        private void frmPrestarPelicula_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet.Prestamo' Puede moverla o quitarla según sea necesario.
            this.prestamoTableAdapter.Fill(this._videoclub_brandomDataSet.Prestamo);
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet.Peliculas' Puede moverla o quitarla según sea necesario.
            this.peliculasTableAdapter.Fill(this._videoclub_brandomDataSet.Peliculas);
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet.Socios' Puede moverla o quitarla según sea necesario.
            this.sociosTableAdapter.Fill(this._videoclub_brandomDataSet.Socios);
            if (sociosBindingSource.Count == 0)
            {
                MessageBox.Show("No existen socios para generar un alquiler");
                Close();
            }
            if (peliculasBindingSource.Count == 0)
            {
                MessageBox.Show("No existen películas para generar un alquiler");
                Close();
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //txtSocio.Text = dataGridView1.CurrentCell.Value.ToString();
            nif1 = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            nombre1 = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            apellido1 = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            
            if (nombre1 == "" || apellido1 == "" || nif1 == "")
            {
                lblOkSoc.Text = "0";
            }
            else
            {
                lblOkSoc.Text = "OK";
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //txtSocio.Text = dataGridView1.CurrentCell.Value.ToString();
            registroPeli = Convert.ToInt32(dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString());
            tituloPeli = dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString();
            //txtSocio.Text = registroPeli + " " + tituloPeli;
            if (tituloPeli == "")
            {
                lblOkPel.Text = "0";
            }
            else
            {
                lblOkPel.Text = "OK";
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        

       

        

        
       

    }  
}

