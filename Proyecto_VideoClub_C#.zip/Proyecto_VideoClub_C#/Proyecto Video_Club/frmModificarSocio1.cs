﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Proyecto_Video_Club
{
    public partial class frmModificarSocio1 : Form
    {
        
        public frmModificarSocio1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void frmModificarSocio1_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet.Socios' Puede moverla o quitarla según sea necesario.
            this.sociosTableAdapter.Fill(this._videoclub_brandomDataSet.Socios);
            if (sociosBindingSource1.Count == 0)
            { 
                MessageBox.Show("No existen registros para modificar");
                Close();
            }
            DataGridViewButtonColumn modificar = new DataGridViewButtonColumn();
            dataGridView1.Columns.Add(modificar);
            modificar.Text = "Modificar Socio";
            modificar.Name = "btnBoton";
            modificar.UseColumnTextForButtonValue = true;
        }

        

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            DialogResult deb = new DialogResult();
            int index = e.ColumnIndex;
            int indexRow;
            indexRow = e.RowIndex;
            if (index == 6)
            {
                deb = MessageBox.Show("¿Seguro que desea devolver está película?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (deb == DialogResult.Yes)
                {
                    sociosBindingSource1.EndEdit();
                    sociosTableAdapter.Update(_videoclub_brandomDataSet.Socios);
                    _videoclub_brandomDataSet.AcceptChanges();
                    MessageBox.Show("Registro modificado correctamente");
                }
                else
                {

                }
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

    }
}
