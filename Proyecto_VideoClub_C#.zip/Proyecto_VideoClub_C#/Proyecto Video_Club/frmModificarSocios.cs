﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace Proyecto_Video_Club
{
    public partial class frmModificarSocios : Form
    {
        OleDbConnection cadena = new OleDbConnection();
        OleDbCommand comando = new OleDbCommand();
        string path_Bd;
        string cs;
        OleDbConnection cn = new OleDbConnection();
        public frmModificarSocios()
        {
            InitializeComponent();
        }

        private void frmModificarSocios_Load(object sender, EventArgs e)
        {          
            
            
            if (sociosBindingSource2.Count == 0) { MessageBox.Show("No existen registros para modificar", "Aviso"); Close(); }
            
        }
        
       
        
        private void button2_Click(object sender, EventArgs e)
        {
            sociosBindingSource2.MovePrevious();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            sociosBindingSource2.MoveNext();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            sociosBindingSource2.MoveFirst();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            sociosBindingSource2.MoveLast();
        }

        private void cmdCerrar_Click(object sender, EventArgs e)
        {
            path_Bd = Directory.GetCurrentDirectory() + Path.DirectorySeparatorChar + "videoclub-brandom.accdb";
            cs = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path_Bd + "";
            if (txtSocNif.Text == "" || txtSocNombre.Text == "" || txtSocApellidos.Text == "" || txtDireccion.Text == "" || txtTelefono.Text == "" || txtFecha.Text == "")
            {
                MessageBox.Show("Los campos no pueden estar vacios", "Aviso");
            }
            else
            {



                try
                {
                    cn.ConnectionString = cs;
                    
                    //OleDbCommand actualizar = new OleDbCommand();
                    //actualizar.CommandType = CommandType.Text;
                    comando.CommandType = CommandType.Text;
                    comando.CommandText = "UPDATE Socios SET Nif=@txtSocNif,Nombre=@txtSocNombre,Apellidos=@txtSocApellidos,Dirección=@txtDireccion,Teléfono=@txtTelefono,Fecha_introducción=@txtFecha where Id=@txtId";
                    //comando = new OleDbCommand(actualizar, cn);
                    comando.Parameters.AddWithValue("@Nif", txtSocNif.Text);
                    comando.Parameters.AddWithValue("@Nombre", txtSocNombre.Text);
                    comando.Parameters.AddWithValue("@Apellidos", txtSocApellidos.Text);
                    comando.Parameters.AddWithValue("@Dirección", txtDireccion.Text);
                    comando.Parameters.AddWithValue("@Teléfono", txtTelefono.Text);
                    comando.Parameters.AddWithValue("@Fecha_introducción", txtFecha.Text);
                    comando.Parameters.AddWithValue("@Id", txtId.Text);
                    comando.Connection = cn;
                    cn.Open();
                    comando.ExecuteNonQuery();
                    MessageBox.Show("Socio Modificado Correctamente", "Mensaje");
                    cn.Close();
                }
                catch (OleDbException ex)
                {

                    MessageBox.Show("No se puedo modificar el registro" + ex);
                    cn.Close();

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        

        
    }
}
