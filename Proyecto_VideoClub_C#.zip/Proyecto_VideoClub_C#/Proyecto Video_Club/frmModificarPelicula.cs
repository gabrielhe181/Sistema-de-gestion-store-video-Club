﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Proyecto_Video_Club
{
    public partial class frmModificarPelicula : Form
    {
        public frmModificarPelicula()
        {
            InitializeComponent();
        }

        private void frmModificarPelicula_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet.Peliculas' Puede moverla o quitarla según sea necesario.
            this.peliculasTableAdapter.Fill(this._videoclub_brandomDataSet.Peliculas);
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet5.Peliculas' Puede moverla o quitarla según sea necesario.
            
            if (peliculasBindingSource1.Count == 0)
            {
                MessageBox.Show("No existen registros para modificar");
                Close();
            }
            DataGridViewButtonColumn modificar = new DataGridViewButtonColumn();
            dataGridView1.Columns.Add(modificar);
            modificar.Text = "Modificar Película";
            modificar.Name = "btnBoton";
            modificar.UseColumnTextForButtonValue = true;
        }

        
            
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DialogResult deb = new DialogResult();
            int index = e.ColumnIndex;
            int indexRow;
            indexRow = e.RowIndex;
            if (index == 8)
            {
                deb = MessageBox.Show("¿Seguro que desea devolver está película?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (deb == DialogResult.Yes)
                {
                    peliculasBindingSource1.EndEdit();
                    peliculasTableAdapter.Update(_videoclub_brandomDataSet.Peliculas);
                    _videoclub_brandomDataSet.AcceptChanges();
                    MessageBox.Show("Registro modificado correctamente");
                }
                else
                {

                }
            }
        }
    }
}
