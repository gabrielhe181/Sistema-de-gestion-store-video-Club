﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Proyecto_Video_Club
{
    public partial class frmBuscarPelicula : Form
    {
        public frmBuscarPelicula()
        {
            InitializeComponent();
        }

        private void frmBuscarPelicula_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet.Peliculas' Puede moverla o quitarla según sea necesario.
            this.peliculasTableAdapter.Fill(this._videoclub_brandomDataSet.Peliculas);
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet5.Peliculas' Puede moverla o quitarla según sea necesario.
            
            if (peliculasBindingSource.Count == 0)
            {
                MessageBox.Show("No existen películas para buscar");
                Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string filtro;
            filtro = "Titulo like '" + txtBuscar.Text + "%' OR Director like '" + txtBuscar.Text + "%' OR Productor like '" + txtBuscar.Text + "%' OR Publico like '" + txtBuscar.Text + "%' OR Genero like '" + txtBuscar.Text + "%' OR Anio like '" + txtBuscar.Text + "%'";
            try
            {
                peliculasBindingSource.Filter = filtro;
                if (peliculasBindingSource.Count == 0)
                {
                    MessageBox.Show("No se encontro el registro");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Mensaje" + ex);
            }
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            if (txtBuscar.Text == "")
            {
                peliculasBindingSource.Filter = "";
            }
        }
    }
}
