﻿namespace Proyecto_Video_Club
{
    partial class frmDevolverPelicula
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.registroPelículaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tituloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apellidoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaPréstamoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaDevoluciónDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valorAlquilerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalAlquilerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.devueltoDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.prestamoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this._videoclub_brandomDataSet = new Proyecto_Video_Club._videoclub_brandomDataSet();
            this.prestamoTableAdapter = new Proyecto_Video_Club._videoclub_brandomDataSetTableAdapters.PrestamoTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prestamoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._videoclub_brandomDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.registroPelículaDataGridViewTextBoxColumn,
            this.tituloDataGridViewTextBoxColumn,
            this.nombreDataGridViewTextBoxColumn,
            this.apellidoDataGridViewTextBoxColumn,
            this.fechaPréstamoDataGridViewTextBoxColumn,
            this.fechaDevoluciónDataGridViewTextBoxColumn,
            this.valorAlquilerDataGridViewTextBoxColumn,
            this.totalAlquilerDataGridViewTextBoxColumn,
            this.devueltoDataGridViewCheckBoxColumn});
            this.dataGridView2.DataSource = this.prestamoBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(12, 12);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(889, 424);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // registroPelículaDataGridViewTextBoxColumn
            // 
            this.registroPelículaDataGridViewTextBoxColumn.DataPropertyName = "Registro Película";
            this.registroPelículaDataGridViewTextBoxColumn.HeaderText = "Rpelícula";
            this.registroPelículaDataGridViewTextBoxColumn.Name = "registroPelículaDataGridViewTextBoxColumn";
            this.registroPelículaDataGridViewTextBoxColumn.ReadOnly = true;
            this.registroPelículaDataGridViewTextBoxColumn.Width = 78;
            // 
            // tituloDataGridViewTextBoxColumn
            // 
            this.tituloDataGridViewTextBoxColumn.DataPropertyName = "Titulo";
            this.tituloDataGridViewTextBoxColumn.HeaderText = "Titulo";
            this.tituloDataGridViewTextBoxColumn.Name = "tituloDataGridViewTextBoxColumn";
            this.tituloDataGridViewTextBoxColumn.ReadOnly = true;
            this.tituloDataGridViewTextBoxColumn.Width = 58;
            // 
            // nombreDataGridViewTextBoxColumn
            // 
            this.nombreDataGridViewTextBoxColumn.DataPropertyName = "Nombre";
            this.nombreDataGridViewTextBoxColumn.HeaderText = "Nombre";
            this.nombreDataGridViewTextBoxColumn.Name = "nombreDataGridViewTextBoxColumn";
            this.nombreDataGridViewTextBoxColumn.ReadOnly = true;
            this.nombreDataGridViewTextBoxColumn.Width = 69;
            // 
            // apellidoDataGridViewTextBoxColumn
            // 
            this.apellidoDataGridViewTextBoxColumn.DataPropertyName = "Apellido";
            this.apellidoDataGridViewTextBoxColumn.HeaderText = "Apellido";
            this.apellidoDataGridViewTextBoxColumn.Name = "apellidoDataGridViewTextBoxColumn";
            this.apellidoDataGridViewTextBoxColumn.ReadOnly = true;
            this.apellidoDataGridViewTextBoxColumn.Width = 69;
            // 
            // fechaPréstamoDataGridViewTextBoxColumn
            // 
            this.fechaPréstamoDataGridViewTextBoxColumn.DataPropertyName = "Fecha Préstamo";
            this.fechaPréstamoDataGridViewTextBoxColumn.HeaderText = "Fecha Préstamo";
            this.fechaPréstamoDataGridViewTextBoxColumn.Name = "fechaPréstamoDataGridViewTextBoxColumn";
            this.fechaPréstamoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fechaDevoluciónDataGridViewTextBoxColumn
            // 
            this.fechaDevoluciónDataGridViewTextBoxColumn.DataPropertyName = "Fecha devolución";
            this.fechaDevoluciónDataGridViewTextBoxColumn.HeaderText = "Fecha devolución";
            this.fechaDevoluciónDataGridViewTextBoxColumn.Name = "fechaDevoluciónDataGridViewTextBoxColumn";
            this.fechaDevoluciónDataGridViewTextBoxColumn.ReadOnly = true;
            this.fechaDevoluciónDataGridViewTextBoxColumn.Width = 107;
            // 
            // valorAlquilerDataGridViewTextBoxColumn
            // 
            this.valorAlquilerDataGridViewTextBoxColumn.DataPropertyName = "ValorAlquiler";
            this.valorAlquilerDataGridViewTextBoxColumn.HeaderText = "ValorAlquiler";
            this.valorAlquilerDataGridViewTextBoxColumn.Name = "valorAlquilerDataGridViewTextBoxColumn";
            this.valorAlquilerDataGridViewTextBoxColumn.ReadOnly = true;
            this.valorAlquilerDataGridViewTextBoxColumn.Width = 90;
            // 
            // totalAlquilerDataGridViewTextBoxColumn
            // 
            this.totalAlquilerDataGridViewTextBoxColumn.DataPropertyName = "TotalAlquiler";
            this.totalAlquilerDataGridViewTextBoxColumn.HeaderText = "TotalAlquiler";
            this.totalAlquilerDataGridViewTextBoxColumn.Name = "totalAlquilerDataGridViewTextBoxColumn";
            this.totalAlquilerDataGridViewTextBoxColumn.ReadOnly = true;
            this.totalAlquilerDataGridViewTextBoxColumn.Width = 90;
            // 
            // devueltoDataGridViewCheckBoxColumn
            // 
            this.devueltoDataGridViewCheckBoxColumn.DataPropertyName = "Devuelto";
            this.devueltoDataGridViewCheckBoxColumn.HeaderText = "Devuelto";
            this.devueltoDataGridViewCheckBoxColumn.Name = "devueltoDataGridViewCheckBoxColumn";
            this.devueltoDataGridViewCheckBoxColumn.ReadOnly = true;
            this.devueltoDataGridViewCheckBoxColumn.Width = 56;
            // 
            // prestamoBindingSource
            // 
            this.prestamoBindingSource.DataMember = "Prestamo";
            this.prestamoBindingSource.DataSource = this._videoclub_brandomDataSet;
            // 
            // _videoclub_brandomDataSet
            // 
            this._videoclub_brandomDataSet.DataSetName = "_videoclub_brandomDataSet";
            this._videoclub_brandomDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // prestamoTableAdapter
            // 
            this.prestamoTableAdapter.ClearBeforeFill = true;
            // 
            // frmDevolverPelicula
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(913, 448);
            this.Controls.Add(this.dataGridView2);
            this.Name = "frmDevolverPelicula";
            this.Text = " ";
            this.Load += new System.EventHandler(this.frmDevolverPelicula_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prestamoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._videoclub_brandomDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView2;
        private _videoclub_brandomDataSet _videoclub_brandomDataSet;
        private System.Windows.Forms.BindingSource prestamoBindingSource;
        private Proyecto_Video_Club._videoclub_brandomDataSetTableAdapters.PrestamoTableAdapter prestamoTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn registroPelículaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tituloDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn apellidoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaPréstamoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaDevoluciónDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valorAlquilerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalAlquilerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn devueltoDataGridViewCheckBoxColumn;
    }
}