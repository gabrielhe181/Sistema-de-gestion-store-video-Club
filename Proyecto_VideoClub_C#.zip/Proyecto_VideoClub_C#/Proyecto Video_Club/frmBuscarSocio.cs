﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Proyecto_Video_Club
{
    public partial class frmBuscarSocio : Form
    {
        public frmBuscarSocio()
        {
            InitializeComponent();
        }

        private void frmBuscarSocio_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet.Socios' Puede moverla o quitarla según sea necesario.
            this.sociosTableAdapter.Fill(this._videoclub_brandomDataSet.Socios);
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet5.Socios' Puede moverla o quitarla según sea necesario.
            if (sociosBindingSource.Count == 0)
            {
                MessageBox.Show("No existen registros para buscar");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string filtro;
            filtro = "Nif like '" + txtBuscar.Text + "%' OR Nombre like '" + txtBuscar.Text + "%' OR Apellidos like '" + txtBuscar.Text + "%' OR Dirección like '" + txtBuscar.Text + "%' OR Teléfono like '" + txtBuscar.Text + "%'";
            try
            {
                sociosBindingSource.Filter = filtro;
                if(sociosBindingSource.Count == 0)
                {
                    MessageBox.Show("No se encontro el registro");
                }
            }catch (Exception ex)
            {
                MessageBox.Show("Mensaje" + ex);
            }
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            if (txtBuscar.Text == "")
            {
                sociosBindingSource.Filter = "";
            }
        }
    }
}
