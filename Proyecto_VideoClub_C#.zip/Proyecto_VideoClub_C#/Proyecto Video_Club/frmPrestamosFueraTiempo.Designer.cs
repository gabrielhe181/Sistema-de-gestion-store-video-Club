﻿namespace Proyecto_Video_Club
{
    partial class frmPrestamosFueraTiempo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.prestamoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this._videoclub_brandomDataSet = new Proyecto_Video_Club._videoclub_brandomDataSet();
            this.prestamoTableAdapter = new Proyecto_Video_Club._videoclub_brandomDataSetTableAdapters.PrestamoTableAdapter();
            this.sociosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sociosTableAdapter = new Proyecto_Video_Club._videoclub_brandomDataSetTableAdapters.SociosTableAdapter();
            this.registroPelículaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apellidoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tituloDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaPréstamoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaDevoluciónDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valorAlquilerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalAlquilerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.devueltoDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.button2 = new System.Windows.Forms.Button();
            this.txtBuscar = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.prestamoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._videoclub_brandomDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sociosBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.registroPelículaDataGridViewTextBoxColumn,
            this.nombreDataGridViewTextBoxColumn,
            this.apellidoDataGridViewTextBoxColumn,
            this.tituloDataGridViewTextBoxColumn,
            this.fechaPréstamoDataGridViewTextBoxColumn,
            this.fechaDevoluciónDataGridViewTextBoxColumn,
            this.valorAlquilerDataGridViewTextBoxColumn,
            this.totalAlquilerDataGridViewTextBoxColumn,
            this.devueltoDataGridViewCheckBoxColumn});
            this.dataGridView1.DataSource = this.prestamoBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 39);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(931, 435);
            this.dataGridView1.TabIndex = 0;
            // 
            // prestamoBindingSource
            // 
            this.prestamoBindingSource.DataMember = "Prestamo";
            this.prestamoBindingSource.DataSource = this._videoclub_brandomDataSet;
            // 
            // _videoclub_brandomDataSet
            // 
            this._videoclub_brandomDataSet.DataSetName = "_videoclub_brandomDataSet";
            this._videoclub_brandomDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // prestamoTableAdapter
            // 
            this.prestamoTableAdapter.ClearBeforeFill = true;
            // 
            // sociosBindingSource
            // 
            this.sociosBindingSource.DataMember = "Socios";
            this.sociosBindingSource.DataSource = this._videoclub_brandomDataSet;
            // 
            // sociosTableAdapter
            // 
            this.sociosTableAdapter.ClearBeforeFill = true;
            // 
            // registroPelículaDataGridViewTextBoxColumn
            // 
            this.registroPelículaDataGridViewTextBoxColumn.DataPropertyName = "Registro Película";
            this.registroPelículaDataGridViewTextBoxColumn.HeaderText = "Registro Película";
            this.registroPelículaDataGridViewTextBoxColumn.Name = "registroPelículaDataGridViewTextBoxColumn";
            this.registroPelículaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nombreDataGridViewTextBoxColumn
            // 
            this.nombreDataGridViewTextBoxColumn.DataPropertyName = "Nombre";
            this.nombreDataGridViewTextBoxColumn.HeaderText = "Nombre";
            this.nombreDataGridViewTextBoxColumn.Name = "nombreDataGridViewTextBoxColumn";
            this.nombreDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // apellidoDataGridViewTextBoxColumn
            // 
            this.apellidoDataGridViewTextBoxColumn.DataPropertyName = "Apellido";
            this.apellidoDataGridViewTextBoxColumn.HeaderText = "Apellido";
            this.apellidoDataGridViewTextBoxColumn.Name = "apellidoDataGridViewTextBoxColumn";
            this.apellidoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tituloDataGridViewTextBoxColumn
            // 
            this.tituloDataGridViewTextBoxColumn.DataPropertyName = "Titulo";
            this.tituloDataGridViewTextBoxColumn.HeaderText = "Titulo";
            this.tituloDataGridViewTextBoxColumn.Name = "tituloDataGridViewTextBoxColumn";
            this.tituloDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fechaPréstamoDataGridViewTextBoxColumn
            // 
            this.fechaPréstamoDataGridViewTextBoxColumn.DataPropertyName = "Fecha Préstamo";
            this.fechaPréstamoDataGridViewTextBoxColumn.HeaderText = "Fecha Préstamo";
            this.fechaPréstamoDataGridViewTextBoxColumn.Name = "fechaPréstamoDataGridViewTextBoxColumn";
            this.fechaPréstamoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fechaDevoluciónDataGridViewTextBoxColumn
            // 
            this.fechaDevoluciónDataGridViewTextBoxColumn.DataPropertyName = "Fecha devolución";
            this.fechaDevoluciónDataGridViewTextBoxColumn.HeaderText = "Fecha devolución";
            this.fechaDevoluciónDataGridViewTextBoxColumn.Name = "fechaDevoluciónDataGridViewTextBoxColumn";
            this.fechaDevoluciónDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // valorAlquilerDataGridViewTextBoxColumn
            // 
            this.valorAlquilerDataGridViewTextBoxColumn.DataPropertyName = "ValorAlquiler";
            this.valorAlquilerDataGridViewTextBoxColumn.HeaderText = "ValorAlquiler";
            this.valorAlquilerDataGridViewTextBoxColumn.Name = "valorAlquilerDataGridViewTextBoxColumn";
            this.valorAlquilerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // totalAlquilerDataGridViewTextBoxColumn
            // 
            this.totalAlquilerDataGridViewTextBoxColumn.DataPropertyName = "TotalAlquiler";
            this.totalAlquilerDataGridViewTextBoxColumn.HeaderText = "TotalAlquiler";
            this.totalAlquilerDataGridViewTextBoxColumn.Name = "totalAlquilerDataGridViewTextBoxColumn";
            this.totalAlquilerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // devueltoDataGridViewCheckBoxColumn
            // 
            this.devueltoDataGridViewCheckBoxColumn.DataPropertyName = "Devuelto";
            this.devueltoDataGridViewCheckBoxColumn.HeaderText = "Devuelto";
            this.devueltoDataGridViewCheckBoxColumn.Name = "devueltoDataGridViewCheckBoxColumn";
            this.devueltoDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(841, 10);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(102, 23);
            this.button2.TabIndex = 30;
            this.button2.Text = "Buscar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtBuscar
            // 
            this.txtBuscar.Location = new System.Drawing.Point(85, 12);
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Size = new System.Drawing.Size(750, 20);
            this.txtBuscar.TabIndex = 29;
            this.txtBuscar.TextChanged += new System.EventHandler(this.txtBuscar_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 16);
            this.label1.TabIndex = 28;
            this.label1.Text = "BUSCAR:";
            // 
            // frmPrestamosFueraTiempo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(955, 486);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txtBuscar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "frmPrestamosFueraTiempo";
            this.Text = "Prestamos fuera de tiempo";
            this.Load += new System.EventHandler(this.frmPrestamosFueraTiempo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.prestamoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._videoclub_brandomDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sociosBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private _videoclub_brandomDataSet _videoclub_brandomDataSet;
        private System.Windows.Forms.BindingSource prestamoBindingSource;
        private Proyecto_Video_Club._videoclub_brandomDataSetTableAdapters.PrestamoTableAdapter prestamoTableAdapter;
        private System.Windows.Forms.BindingSource sociosBindingSource;
        private Proyecto_Video_Club._videoclub_brandomDataSetTableAdapters.SociosTableAdapter sociosTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn registroPelículaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn apellidoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tituloDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaPréstamoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaDevoluciónDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valorAlquilerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalAlquilerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn devueltoDataGridViewCheckBoxColumn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtBuscar;
        private System.Windows.Forms.Label label1;
    }
}