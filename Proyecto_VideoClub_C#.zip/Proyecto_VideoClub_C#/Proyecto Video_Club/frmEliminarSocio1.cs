﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace Proyecto_Video_Club
{
    public partial class frmEliminarSocio1 : Form
    {
        OleDbConnection cadena = new OleDbConnection();
        OleDbCommand comando = new OleDbCommand();
        string path_Bd;
        string cs;
        public frmEliminarSocio1()
        {
            InitializeComponent();
        }

        private void frmEliminarSocio1_Load(object sender, EventArgs e)
        {          
          
            OleDbConnection cn = new OleDbConnection();
            frmEliminarSocio eliminar = new frmEliminarSocio();
            //string numero;
            //numero = eliminar.txtId.Text;   
            path_Bd = Directory.GetCurrentDirectory() + Path.DirectorySeparatorChar + "videoclub-brandom.accdb";
            cs = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path_Bd + "";
            cn.ConnectionString = cs;
            eliminar.Close();
            try
                {
                    

                    //OleDbCommand actualizar = new OleDbCommand();
                    //actualizar.CommandType = CommandType.Text;
                    comando.CommandType = CommandType.Text;
                    comando.CommandText = "DELETE from Socios where [Id]=@numero";
                    //comando.Parameters.AddWithValue("@Id", numero);
                    comando.Connection = cn;
                    cn.Open();
                    comando.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Registro eliminado correctamente");
                    Close();
                    eliminar.ShowDialog();
                }
                catch (OleDbException ex)
                {
                    MessageBox.Show("aviso"+ex);
                    cn.Close();
                    Close();

                }
            
            }
        
    }
}
