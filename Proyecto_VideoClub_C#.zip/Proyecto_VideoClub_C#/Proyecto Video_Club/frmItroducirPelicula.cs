﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace Proyecto_Video_Club
{
    public partial class frmItroducirPelicula : Form
    {

        public frmItroducirPelicula()
        {
            InitializeComponent();
        }
        
        private void frmItroducirPelicula_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet.Peliculas' Puede moverla o quitarla según sea necesario.
            this.peliculasTableAdapter.Fill(this._videoclub_brandomDataSet.Peliculas);
            
            if (peliculasBindingSource.Count == 0)
            {

            }
            else
            { 
                peliculasBindingSource.MoveLast();
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int dato = 0;
            if (txtRegistro.Text == "")
            {
                txtRegistro.Text = "1";
                dato = 1;
                
            }
            else
            {
                dato = Convert.ToInt32(txtRegistro.Text)+1;
                
            }
            if (txtActores.Text == "" || txtAnio.Text == "" || txtDireccion.Text == "" || txtProductor.Text == "" || txtTitulo.Text == "")
            { 
              MessageBox.Show("Los registros no pueden estar vacios"); 
            }
            else
            { 
              try
              {
                peliculasTableAdapter.Insert(dato, txtTitulo.Text, txtDireccion.Text, txtProductor.Text, cboPublico.Text, cboGenero.Text, txtAnio.Text,txtActores.Text);
                txtRegistro.Text = "";
                peliculasBindingSource.MoveLast();
                limpiar();
                MessageBox.Show("Película agregada correctamente"); 
              }
                catch (Exception ex)
                {
                  MessageBox.Show("No se pudo agregar el registro" + ex);
                }
            
           }
         }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void limpiar()
        {
            txtActores.Text = "";
            txtAnio.Text = "";
            txtDireccion.Text = "";
            txtProductor.Text = "";
            txtTitulo.Text = "";
        }

    }
}
