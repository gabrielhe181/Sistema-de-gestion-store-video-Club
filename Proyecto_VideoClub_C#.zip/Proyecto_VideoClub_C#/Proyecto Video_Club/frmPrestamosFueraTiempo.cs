﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Proyecto_Video_Club
{
    public partial class frmPrestamosFueraTiempo : Form
    {
        public frmPrestamosFueraTiempo()
        {
            InitializeComponent();
        }

        private void frmPrestamosFueraTiempo_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet.Socios' Puede moverla o quitarla según sea necesario.
            this.sociosTableAdapter.Fill(this._videoclub_brandomDataSet.Socios);
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet.Prestamo' Puede moverla o quitarla según sea necesario.
            this.prestamoTableAdapter.Fill(this._videoclub_brandomDataSet.Prestamo);
            prestamoBindingSource.Filter = "[Fecha Préstamo] < [Fecha devolución] AND Devuelto=True";
            
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            if (txtBuscar.Text == "")
            {
                prestamoBindingSource.Filter = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            prestamoBindingSource.Filter = "Nombre Like '"+txtBuscar.Text+"%' OR Apellido Like '"+txtBuscar.Text+"%' OR Titulo Like '"+txtBuscar.Text+"%'";
        }
    }
}
