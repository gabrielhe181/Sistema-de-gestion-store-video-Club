﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Proyecto_Video_Club
{
    public partial class MDIPrincipal : Form
    {
        private int childFormNumber = 0;

        public MDIPrincipal()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Abrir copia de seguridad";
            openFileDialog1.Filter = "Archivos de base de datos (*.mdb)|*.mdb| Archivos de texto (*.txt)|*.txt| Todos los archivos (*.*)|*.*";
            openFileDialog1.ShowDialog();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Abrir copia de seguridad";
            openFileDialog1.Filter = "Archivos de base de datos (*.mdb)|*.mdb| Archivos de texto (*.txt)|*.txt| Todos los archivos (*.*)|*.*";
            openFileDialog1.ShowDialog();
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Archivos de texto (*.txt)|*.txt|Todos los archivos (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void mnuArchivoCopia_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Title = "Guardar copia de seguridad";
            saveFileDialog1.Filter = "Archivos de base de datos (*.mdb)|*.mdb| Archivos de texto (*.txt)|*.txt| Todos los archivos (*.*)|*.*";
            saveFileDialog1.ShowDialog();
        }

        private void mnuCopiaSeguridad_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Title = "Guardar copia de seguridad";
            saveFileDialog1.Filter = "Archivos de base de datos (*.mdb)|*.mdb| Archivos de texto (*.txt)|*.txt| Todos los archivos (*.*)|*.*";
            saveFileDialog1.ShowDialog();
        }

        private void imprimirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printDialog1.ShowDialog();
        }

        private void mnuImprimir_Click(object sender, EventArgs e)
        {
            printDialog1.ShowDialog();
        }

        private void mnuAyudaAcercade_Click(object sender, EventArgs e)
        {
          Form nuevo = new frmAcercade();
          nuevo.ShowDialog();
        }

        private void mnuIntroducirSocio_Click(object sender, EventArgs e)
        {
            Form nuevo1 = new frmIntroducirSocios();
            nuevo1.ShowDialog();
        }

        

        private void socioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form form2 = new frmModificarSocio1();
            form2.ShowDialog();
        }

        private void socioToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form EliminarSocio = new frmEliminarSocio();
            EliminarSocio.ShowDialog();
        }

        private void mnuInformesBuscarBuscarSocio_Click(object sender, EventArgs e)
        {
            frmBuscarSocio buscar = new frmBuscarSocio();
            buscar.ShowDialog();
        }

        private void mnuIntroducirPelicula_Click(object sender, EventArgs e)
        {
            frmItroducirPelicula Ipelicula = new frmItroducirPelicula();
            Ipelicula.ShowDialog();
        }

        private void películaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmEliminarPelicula ePelicula = new frmEliminarPelicula();
            ePelicula.ShowDialog();
        }

        private void mnuBuscar_Click(object sender, EventArgs e)
        {
            Form modificar = new frmModificarSocios();
            modificar.ShowDialog();
        }

        private void películaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmModificarPelicula modificarP = new frmModificarPelicula();
            modificarP.ShowDialog();
        }

        private void mnuInformesBuscarBuscarPelicula_Click(object sender, EventArgs e)
        {
            frmBuscarPelicula peliculaB = new frmBuscarPelicula();
            peliculaB.ShowDialog();
        }

        private void mnuPrestamosPrestarPelicula_Click(object sender, EventArgs e)
        {
            frmPrestarPelicula prestar = new frmPrestarPelicula();
            prestar.ShowDialog();
        }

        private void mnuPrestamosDevolverPelicula_Click(object sender, EventArgs e)
        {
            frmDevolverPelicula devolver = new frmDevolverPelicula();
            devolver.ShowDialog();
        }

        private void alquileresFueraDeTiempoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPrestamosFueraTiempo fueraTiempo = new frmPrestamosFueraTiempo();
            fueraTiempo.ShowDialog();
        }
    }
}
