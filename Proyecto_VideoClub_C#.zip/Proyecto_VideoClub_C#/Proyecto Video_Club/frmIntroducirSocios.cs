﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace Proyecto_Video_Club
{
    public partial class frmIntroducirSocios : Form
    {        
        public frmIntroducirSocios()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cmdCerrar_Click(object sender, EventArgs e)
        {
            if (txtSocNif.Text == "" || txtSocNombre.Text == "" || txtSocApellidos.Text == "" || txtDireccion.Text == "" || txtTelefono.Text == "")
            { MessageBox.Show("Los campos no pueden estar vacios"); }
            else
            {
                sociosTableAdapter.Insert(txtSocNif.Text, txtSocNombre.Text, txtSocApellidos.Text, txtDireccion.Text, txtTelefono.Text, dateTimePicker1.Value);
                limpiar();
                MessageBox.Show("Socio agregado correctamente");
                
            }
        
        }

        private void frmIntroducirSocios_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla '_videoclub_brandomDataSet.Socios' Puede moverla o quitarla según sea necesario.
            this.sociosTableAdapter.Fill(this._videoclub_brandomDataSet.Socios);
            
                       
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void limpiar()
        {
            txtSocNif.Text = "";
            txtSocNombre.Text = "";
            txtSocApellidos.Text = "";
            txtDireccion.Text = "";
            txtTelefono.Text = "";
        }
        
    }
}
